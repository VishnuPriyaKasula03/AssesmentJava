package com.main.service;


import java.util.List;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.StudentFeedback;
import com.main.model.TeacherFeedback;
import com.main.model.TimeTable;

public interface StudentService {

	public void saveStudent(Student student);
	
	List<Student> fetchStudentList();
	List<TimeTable>  fetchTimeTableList(String standard);

	List<Enotes> fetchEnotesList(String standard);

	List<Fee> fetchFeeList(Integer studentId);

	public void TeacherFeedback(TeacherFeedback teacherFeedback);

	public List<StudentFeedback> fetchFeedbackList(Integer studentid);
	


}
